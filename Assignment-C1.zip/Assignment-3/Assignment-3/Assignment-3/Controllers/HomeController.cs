﻿using Assignment_3.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.Extensions.Configuration;
namespace Assignment_3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            SchoolDbContext context = new SchoolDbContext(Assignment_3.Properties.Resources.ConnectionString);

            return View(context.GetAllTeachers());
        }
        
             public IActionResult Class()
        {
            SchoolDbContext context = new SchoolDbContext(Assignment_3.Properties.Resources.ConnectionString);

            return View(context.GetAllClass());
        }
        [HttpGet("/Home/AddTeacher", Name = nameof(AddTeacher))]
        public IActionResult AddTeacher()
        {


            return View();
        }
        [HttpGet("/Home/AddClass", Name = nameof(AddClass))]
        public IActionResult AddClass()
        {


            return View();
        }

        [HttpGet("/{classId}/deleteclass", Name = nameof(Class))]
        public IActionResult Class(Class m)
        {
            SchoolDbContext context = new SchoolDbContext(Assignment_3.Properties.Resources.ConnectionString);
            context.deleteClass(m.classId);
            return View(context.GetAllClass());
        }
        [HttpGet("/{teacherId}/delete", Name = nameof(Index))]
        public IActionResult Index(Teacher m)
        {
            SchoolDbContext context = new SchoolDbContext(Assignment_3.Properties.Resources.ConnectionString);
            context.deleteTeacher(m.teacherId);
            return View(context.GetAllTeachers());
        }
        [HttpPost("/Home/Create", Name = nameof(saveTeacher))]
        public IActionResult saveTeacher(Teacher m)
        {
     

            SchoolDbContext context = new SchoolDbContext(Assignment_3.Properties.Resources.ConnectionString);
            context.addTeacher(m);
            return View(context.GetAllTeachers());
        }
        [HttpPost("/Home/Class", Name = nameof(saveClass))]
        public IActionResult saveClass(Class m)
        {


            SchoolDbContext context = new SchoolDbContext(Assignment_3.Properties.Resources.ConnectionString);
            context.addClass(m);
            return View(context.GetAllClass());
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}