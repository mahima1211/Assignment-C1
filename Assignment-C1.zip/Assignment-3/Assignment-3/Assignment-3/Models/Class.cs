﻿namespace Assignment_3.Models
{
    public class Class
    {
        private SchoolDbContext context;
        public int classId { get; set; }
        public String classcode { get; set; }
        public int teacherid { get; set; }
        public String startdate { get; set; }
        public String finishdate { get; set; }
        public String classname { get; set; }
    }
}
