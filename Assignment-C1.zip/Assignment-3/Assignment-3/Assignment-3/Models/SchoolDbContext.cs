﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
namespace Assignment_3.Models
{
    public class SchoolDbContext
    {
        public string ConnectionString { get; set; }

        public SchoolDbContext(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(ConnectionString);
        }
        public List<Teacher> GetAllTeachers()
        {
            List<Teacher> list = new List<Teacher>();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("select * from teachers", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Teacher()
                        {
                            teacherId = Convert.ToInt32(reader["teacherid"]),
                            teacherFname = reader["teacherfname"].ToString(),
                            teacherlName = reader["teacherlname"].ToString(),
                            employeenumber = reader["employeenumber"].ToString(),
                            hiredate = reader["hiredate"].ToString(),
                            salary = Convert.ToDecimal(reader["salary"])
                        });
                    }
                }
            }

            return list;
        }
        public List<Class> GetAllClass()
        {
            List<Class> list = new List<Class>();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("select * from classes", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Class()
                        {
                            classId = Convert.ToInt32(reader["classid"]),
                            teacherid = Convert.ToInt32( reader["teacherid"]),
                            classcode = reader["classcode"].ToString(),
                            startdate = reader["startdate"].ToString(),
                            finishdate = reader["finishdate"].ToString(),
                            classname = reader["classname"].ToString()
                        });
                    }
                }
            }

            return list;
        }
        public void deleteTeacher(int id)
        {
            MySqlConnection conn = GetConnection();
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("DELETE FROM teachers WHERE teacherid=" + id, conn);
            cmd.ExecuteReader();
        }
        public void deleteClass(int id)
        {
            MySqlConnection conn = GetConnection();
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("DELETE FROM classes WHERE classid=" + id, conn);
            cmd.ExecuteReader();
        }
        public void addTeacher(Teacher obj)
        {
            MySqlConnection conn = GetConnection();
            conn.Open();
            String sql = "INSERT INTO teachers (teacherfname, teacherlname, employeenumber, hiredate,salary)" +
                    "VALUES(" + "'" + obj.teacherFname + "'" + "," + "'" + obj.teacherlName + "'" + "," + "'" + obj.employeenumber + "'" + ", CURRENT_TIMESTAMP" + "," + obj.salary + ")";
            MySqlCommand cmd =
                new MySqlCommand(sql, conn);
            cmd.ExecuteReader();
        }
        public void addClass(Class obj)
        {
            MySqlConnection conn = GetConnection();
            conn.Open();
            String sql = "INSERT INTO classes (classcode, teacherid, startdate, finishdate,classname)" +
                    "VALUES(" + "'" + obj.classcode + "'" + "," + "'" + obj.teacherid + "'" + "," + "'" + obj.startdate + "','" + obj.finishdate + "','" + obj.classname + "')" ;
            MySqlCommand cmd =
                new MySqlCommand(sql, conn);
            cmd.ExecuteReader();
        }
    }
}
