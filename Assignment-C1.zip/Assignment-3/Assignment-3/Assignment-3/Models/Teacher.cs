﻿namespace Assignment_3.Models
{
    public class Teacher
    {
        private SchoolDbContext context;
        public int teacherId { get; set; }
        public String teacherFname { get; set; }
        public String teacherlName { get; set; }
        public String employeenumber { get; set; }
        public String hiredate { get; set; }
        public Decimal salary { get; set; }
    }
}
